const Course = require("../models/courseModel");

/**
 * Creates a course
 *
 * @param {*} req
 * @param {*} res
 */
const coursePost = async (req, res) => {
  let course = new Course(req.body); // Crea una nueva instancia del modelo Course con los datos del cuerpo de la solicitud
  await course.save() // Guarda el curso en la base de datos
    .then(course => {
      res.status(201); // CREATED
      res.header({
        'location': `/api/courses/?id=${course.id}`
      });
      res.json(course); // Devuelve los datos del curso guardado en la respuesta
    })
    .catch(err => {
      res.status(422); // Entidad no procesable
      console.log('error while saving the course', err);
      res.json({
        error: 'There was an error saving the course'
      });
    });
};

/**
 * Get all courses or one
 *
 * @param {*} req
 * @param {*} res
 */
const courseGet = (req, res) => {
  const { name, sort } = req.query;

  let query = Course.find();

  // Filtrar por nombre si se proporciona
  if (name) {
    query = query.where('name', new RegExp(name, 'i'));
  }

  // Ordenar alfabéticamente si se proporciona 'sort' como 'asc' o 'desc'
  if (sort && ['asc', 'desc'].includes(sort.toLowerCase())) {
    const sortDirection = sort.toLowerCase() === 'desc' ? -1 : 1;
    query = query.sort({ name: sortDirection });
  }

  query.populate('teacher')
    .then(courses => {
      res.json(courses);
    })
    .catch(err => {
      res.status(422).json({ error: err });
    });
};


/**
 * Updates a course
 *
 * @param {*} req
 * @param {*} res
 */
const coursePatch = (req, res) => {
  // Verificar si se proporciona un ID de curso válido
  if (req.query && req.query.id) {
    Course.findByIdAndUpdate(req.query.id, req.body, { new: true }) // Busca y actualiza el curso por su ID en la base de datos
      .then(course => {
        if (course) {
          res.status(200); // OK
          res.json(course); // Devuelve los datos del curso actualizado en la respuesta
        } else {
          res.status(404); // No encontrado
          res.json({ error: "Course doesn't exist" });
        }
      })
      .catch(err => {
        res.status(422); // Entidad no procesable
        console.log('error while updating the course', err);
        res.json({ error: 'There was an error updating the course' });
      });
  } else {
    res.status(404); // No encontrado
    res.json({ error: "Course doesn't exist" });
  }
};
/**
 * Deletes a course
 *
 * @param {*} req
 * @param {*} res
 */
const courseDelete = (req, res) => {
  // Verificar si se proporciona un ID de curso válido
  if (req.query && req.query.id) {
    Course.findByIdAndDelete(req.query.id) // Busca y elimina el curso por su ID en la base de datos
      .then(course => {
        if (course) {
          res.status(200); // OK
          res.json({ message: "Course deleted successfully" });
        } else {
          res.status(404); // No encontrado
          res.json({ error: "Course doesn't exist" });
        }
      })
      .catch(err => {
        res.status(422); // Entidad no procesable
        console.log('Error while deleting the course', err);
        res.json({ error: 'There was an error deleting the course' });
      });
  } else {
    res.status(404); // No encontrado
    res.json({ error: "Course doesn't exist" });
  }
};

module.exports = {
  coursePost,
  courseGet,
  coursePatch,
  courseDelete,
};
