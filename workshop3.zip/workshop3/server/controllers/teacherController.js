const Teacher = require("../models/teacherModel");

/**
 * Creates a teacher
 *
 * @param {*} req
 * @param {*} res
 */
const teacherPost = async (req, res) => {
  let teacher = new Teacher();

  teacher.first_name = req.body.first_name; // Obtiene el primer nombre del maestro del cuerpo de la solicitud
  teacher.last_name = req.body.last_name; // Obtiene el apellido del maestro del cuerpo de la solicitud
  teacher.cedula = req.body.cedula; // Obtiene la cédula del maestro del cuerpo de la solicitud
  teacher.age = req.body.age; // Obtiene la edad del maestro del cuerpo de la solicitud

  if (teacher.first_name && teacher.last_name) {
    await teacher.save() // Guarda el maestro en la base de datos
      .then(data => {
        res.status(201); // Creado con éxito
        res.header({
          'location': `/api/teachers/?id=${data.id}`
        });
        res.json(data); // Devuelve los datos del maestro guardado en la respuesta
      })
      .catch(err => {
        res.status(422); // Entidad no procesable
        console.log('error while saving the teacher', err);
        res.json({
          error: 'There was an error saving the teacher'
        });
      });
  } else {
    res.status(422);
    console.log('error while saving the teacher')
    res.json({
      error: 'No valid data provided for teacher'
    });
  }
};

/**
 * Get all teachers
 *
 * @param {*} req
 * @param {*} res
 */
const teacherGet = (req, res) => {
  // Si se requiere un maestro específico
  if (req.query && req.query.id) {
    Teacher.findById(req.query.id) // Busca el maestro por su ID en la base de datos
      .then(teacher => {
        res.json(teacher); // Devuelve los datos del maestro en la respuesta
      })
      .catch(err => {
        res.status(404); // No encontrado
        console.log('error while querying the teacher', err)
        res.json({ error: "Teacher doesn't exist" });
      });
  } else {
    // Obtener todos los maestros
    Teacher.find() // Obtiene todos los maestros de la base de datos
      .then(teachers => {
        res.json(teachers); // Devuelve los datos de todos los maestros en la respuesta
      })
      .catch(err => {
        res.status(422); // Entidad no procesable
        res.json({ error: err });
      });
  }
};

const mongoose = require('mongoose');

const teacherPatch = (req, res) => {
  // Obtener maestro por su ID
  if (req.query && req.query.id && mongoose.Types.ObjectId.isValid(req.query.id)) {
    Teacher.findById(req.query.id, function (err, teacher) {
      if (err) {
        res.status(500); // Error interno del servidor
        console.log('Error while querying the teacher', err);
        res.json({ error: 'An error occurred while querying the teacher' });
      } else if (!teacher) {
        res.status(404); // No encontrado
        res.json({ error: 'Teacher not found' });
      } else {
        // Actualizar el objeto del maestro (patch)
        teacher.first_name = req.body.first_name || teacher.first_name; // Actualiza el nombre del maestro si se proporciona en el cuerpo de la solicitud
        teacher.last_name = req.body.last_name || teacher.last_name; // Actualiza el apellido del maestro si se proporciona en el cuerpo de la solicitud
        teacher.cedula = req.body.cedula || teacher.cedula; // Actualiza la cédula del maestro si se proporciona en el cuerpo de la solicitud
        teacher.age = req.body.age || teacher.age; // Actualiza la edad del maestro si se proporciona en el cuerpo de la solicitud

        teacher.save(function (err) {
          if (err) {
            res.status(500); // Error interno del servidor
            console.log('Error while saving the teacher', err);
            res.json({ error: 'An error occurred while saving the teacher' });
          } else {
            res.status(200); // OK
            res.json(teacher); // Devuelve los datos del maestro actualizado en la respuesta
          }
        });
      }
    });
  } else {
    res.status(400); // Solicitud incorrecta
    res.json({ error: 'Invalid teacher ID' });
  }
};

/**
 * Deletes a teacher
 *
 * @param {*} req
 * @param {*} res
 */
const teacherDelete = (req, res) => {
  // Obtener maestro por su ID
  if (req.query && req.query.id) {
    Teacher.findById(req.query.id, function (err, teacher) {
      if (err) {
        res.status(404); // No encontrado
        console.log('error while querying the teacher', err)
        res.json({ error: "Teacher doesn't exist" });
      }

      teacher.deleteOne(function (err) {
        if (err) {
          res.status(422); // Entidad no procesable
          console.log('error while deleting the teacher', err)
          res.json({
            error: 'There was an error deleting the teacher'
          });
        }
        res.status(204); // Sin contenido
        res.json({});
      });
    });
  } else {
    res.status(404); // No encontrado
    res.json({ error: "Teacher doesn't exist" });
  }
};

module.exports = {
  teacherGet,
  teacherPost,
  teacherPatch,
  teacherDelete
};
