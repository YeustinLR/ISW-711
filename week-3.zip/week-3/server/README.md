# Week 1 - My First Hello World with API


## Install

- Install nvm
- run `nvm use`, this will set the right version of node
- run `npm install` to install dependencies

## Run

- To execute the service run `node index.js`


## Test

- To test this you can use [postman](https://www.postman.com/) or a simple curl request: `curl http://localhost:3000/hello`
