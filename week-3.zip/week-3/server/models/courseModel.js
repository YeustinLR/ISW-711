const mongoose = require('mongoose');

// Definir el esquema de Course
const courseSchema = new mongoose.Schema({
  name: { type: String }, // Campo para el nombre del curso (tipo String)
  credits: { type: Number }, // Campo para los créditos del curso (tipo Number)
  teacher: { // Campo para la referencia al modelo Teacher
    type: mongoose.ObjectId,
    ref: 'Teacher'
  }
});

// Crear y exportar el modelo Course basado en el esquema
module.exports = mongoose.model('Course', courseSchema);
