import React, { useState, useEffect } from 'react';
import './style/Courses.css';

function Courses() {
  const [teachers, setTeachers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [updateCourseData, setUpdateCourseData] = useState({
    id: '',
    name: '',
    credits: '',
    teacherId: ''
  });

  useEffect(() => {
    fetch('http://localhost:3001/api/teachers')
      .then(response => response.json())
      .then(data => setTeachers(data))
      .catch(error => console.log(error));

    fetch('http://localhost:3001/api/courses')
      .then(response => response.json())
      .then(data => setCourses(data))
      .catch(error => console.log(error));
  }, []);

  const fetchCourses = () => {
    fetch('http://localhost:3001/api/courses')
      .then(response => response.json())
      .then(data => setCourses(data))
      .catch(error => console.log(error));
  };

  const handleDeleteCourse = courseId => {
    fetch(`http://localhost:3001/api/courses?id=${courseId}`, {
      method: 'DELETE'
    })
      .then(response => response.json())
      .then(data => {
        if (data.message === 'Course deleted successfully') {
          setCourses(prevCourses => prevCourses.filter(course => course._id !== courseId));
        } else {
          console.log(data.error);
        }
      })
      .catch(error => console.log(error));
  };

  const handleUpdateCourse = course => {
    setUpdateCourseData({
      id: course._id,
      name: course.name,
      credits: course.credits,
      teacherId: course.teacher ? course.teacher._id : ''
    });
  };

  const handleUpdateCourseDataChange = event => {
    setUpdateCourseData(prevData => ({
      ...prevData,
      [event.target.name]: event.target.value
    }));
  };

  const handleUpdateCourseSubmit = event => {
    event.preventDefault();

    const { id, name, credits, teacherId } = updateCourseData;

    fetch(`http://localhost:3001/api/courses?id=${id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name,
        credits,
        teacherId
      })
    })
      .then(response => response.json())
      .then(data => {
        if (data.message === 'Course updated successfully') {
          fetchCourses(); // Obtener los cursos actualizados después de guardar
          setUpdateCourseData({
            id: '',
            name: '',
            credits: '',
            teacherId: ''
          });
        } else {
          console.log(data.error);
        }
      })
      .catch(error => console.log(error));
  };

  return (
    <div>
      <h1>Teachers</h1>
      {teachers.map(teacher => (
        <div className="teacher-card" key={teacher._id}>
          <p>Id: {teacher._id}</p>
          <p>First Name: {teacher.first_name}</p>
          <p>Last Name: {teacher.last_name}</p>
          <p>Cedula: {teacher.cedula}</p>
          <p>Age: {teacher.age}</p>
        </div>
      ))}

      <h1>Courses</h1>
      {courses.map(course => (
        <div className="course-card" key={course._id}>
          <p>Id: {course._id}</p>
          <p>Name: {course.name}</p>
          <p>Credits: {course.credits}</p>
          <p>Teacher: {course.teacher ? course.teacher._id : ''}</p>
          <button className="delete-button" onClick={() => handleDeleteCourse(course._id)}>
            X
          </button>
          {!updateCourseData.id || updateCourseData.id !== course._id ? (
            <button className="update-button" onClick={() => handleUpdateCourse(course)}>
              Update
            </button>
          ) : (
            <div>
              <form onSubmit={handleUpdateCourseSubmit}>
                <input
                  type="text"
                  name="name"
                  value={updateCourseData.name}
                  onChange={handleUpdateCourseDataChange}
                  placeholder="Course Name"
                  required
                />
                <input
                  type="number"
                  name="credits"
                  value={updateCourseData.credits}
                  onChange={handleUpdateCourseDataChange}
                  placeholder="Credits"
                  required
                />
                <input
                  type="text"
                  name="teacherId"
                  value={updateCourseData.teacherId}
                  onChange={handleUpdateCourseDataChange}
                  placeholder="Teacher ID"
                  required
                />
                <button type="submit">Save</button>
                <button onClick={() => setUpdateCourseData({ id: '', name: '', credits: '', teacherId: '' })}>
                  Cancel
                </button>
              </form>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

export default Courses;
