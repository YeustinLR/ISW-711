import React from 'react';
import Courses from './Courses';

const App = () => {
  return (
    <div>
      <h1>Course App</h1>
      <Courses />
    </div>
  );
};

export default App;
